# genomelink-python

```
>>> import genomelink
>>> report = genomelink.Report.fetch(name='eye-color', population='european', token='GENOMELINKTEST')
>>> report.summary['text']
Tend to not have brown eyes, slightly
```
