api_base = 'https://genomelink.io'

from genomelink.oauth import OAuth
from genomelink.resource.report import Report
